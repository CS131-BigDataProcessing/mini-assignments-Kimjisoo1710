#Crime Test
This package includes a function for validating columns in the Crime dataset (validate_functions.py) and a function for calculating the mean and median of the age column (stats_function.py).

#Installation
In order to install this package, use pip:
pip install crime test


